import './App.css';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard 
      firstName={"Matt"}
      lastName={"Hensley"}
      age={ 30 }
      hairColor={"Brown"} />
      <PersonCard 
      firstName={"Cloud"}
      lastName={"Strife"}
      age={ 21 }
      hairColor={"Blonde"} />
      <PersonCard 
      firstName={"G'raha"}
      lastName={"Tia"}
      age={ 324 }
      hairColor={"Red"} />
    </div>
  );
}

export default App;
